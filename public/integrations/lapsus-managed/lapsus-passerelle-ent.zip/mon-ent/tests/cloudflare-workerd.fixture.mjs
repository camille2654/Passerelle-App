// Test entry point only. This file is never deployed as a Pages Function.
import {createHandler} from 'connector.js';
const ORIGIN='https://mon-ent.pages.dev';
const AUTH='https://fixture-auth.supabase.co';
const KEY='k'.repeat(43);
export default {async fetch(request){
  const path=new URL(request.url).pathname,scenario=request.headers.get('x-fixture-scenario')||'ready';
  if(path==='/__unsupported-redirect'){
    try{new Request(AUTH,{redirect:'error'});return Response.json({accepted:true});}
    catch(error){return Response.json({accepted:false,name:error.name,message:error.message});}
  }
  const calls=[],logs=[];
  const handle=createHandler({logger:entry=>logs.push(entry),fetcher:async(url,options)=>{
    calls.push({target:String(url).startsWith(AUTH)?'auth':'passerelle',redirect:options.redirect});
    if(scenario==='auth-network'&&String(url).startsWith(AUTH)||scenario==='upstream-network'&&!String(url).startsWith(AUTH))throw new Error('secret-diagnostic-must-not-appear');
    const headers=new Headers(options.headers);headers.set('x-fixture-scenario',scenario);
    return fetch(url,{...options,headers});
  }});
  const response=await handle({request:new Request(ORIGIN+path,{method:request.method,headers:request.headers,...(request.method==='GET'?{}:{body:request.body})}),env:{PASSERELLE_MANAGED_KEY:KEY,LAPSUS_SUPABASE_URL:AUTH,LAPSUS_SUPABASE_PUBLISHABLE_KEY:'sb_publishable_fixture_public_key_12345'}});
  const headers=new Headers(response.headers);
  headers.set('x-fixture-auth-calls',String(calls.filter(row=>row.target==='auth').length));
  headers.set('x-fixture-upstream-calls',String(calls.filter(row=>row.target==='passerelle').length));
  headers.set('x-fixture-redirect-modes',calls.map(row=>row.redirect).join(','));
  headers.set('x-fixture-diagnostics',JSON.stringify(logs));
  return new Response(response.body,{status:response.status,headers});
}};
