import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import net from 'node:net';

const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const binary=process.env.WORKERD_BINARY;
if(!binary||!fs.existsSync(binary))throw new Error('Set WORKERD_BINARY to the installed workerd executable (tested with workerd@1.20261106.1).');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'lapsus-workerd-'));
const server=net.createServer();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const port=server.address().port;await new Promise(resolve=>server.close(resolve));
for(const [from,to]of [['functions/api/passerelle/[[path]].js','connector.js'],['tests/cloudflare-workerd.fixture.mjs','entry.mjs'],['tests/cloudflare-outbound.fixture.mjs','outbound.mjs']])fs.copyFileSync(path.join(project,from),path.join(temp,to));
fs.writeFileSync(path.join(temp,'config.capnp'),`using Workerd = import "/workerd/workerd.capnp";
const config :Workerd.Config = (
 services = [
  (name = "main", worker = (compatibilityDate = "2026-11-06", modules = [(name = "entry.mjs", esModule = embed "entry.mjs"), (name = "connector.js", esModule = embed "connector.js")], globalOutbound = (name = "fixtures"))),
  (name = "fixtures", worker = (compatibilityDate = "2026-11-06", modules = [(name = "outbound.mjs", esModule = embed "outbound.mjs")], globalOutbound = (name = "internet"))),
  (name = "internet", network = (allow = []))
 ],
 sockets = [(name = "http", address = "127.0.0.1:${port}", http = (), service = "main")]
);`);
const child=spawn(binary,['serve',path.join(temp,'config.capnp')],{stdio:['ignore','pipe','pipe']});let output='';child.stdout.on('data',value=>output+=value);child.stderr.on('data',value=>output+=value);
const closed=new Promise(resolve=>child.once('close',resolve)),root='http://127.0.0.1:'+port;
const token='synthetic-lapsus-session-token-123456789';
async function request(scenario='ready',route='/api/passerelle/connection',body){
 const response=await fetch(root+route,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+token,Origin:'https://mon-ent.pages.dev','x-fixture-scenario':scenario,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(10000)});
 return {response,body:await response.json()};
}
try{
 let ready=false;
 for(let i=0;i<80;i++){
  if(child.exitCode!==null)throw new Error('workerd startup failed: '+output.slice(-3000));
  try{const response=await fetch(root+'/__unsupported-redirect',{signal:AbortSignal.timeout(1000)});const value=await response.json();assert.equal(value.accepted,false);assert.equal(value.name,'TypeError');assert.match(value.message,/redirect/i);ready=true;break;}catch{}
  await new Promise(resolve=>setTimeout(resolve,100));
 }
 assert.equal(ready,true,'workerd must actually start and reject the original unsupported option');
 let result=await request();assert.equal(result.response.status,200);assert.equal(result.body.connectionId,null);assert.equal(result.response.headers.get('x-fixture-redirect-modes'),'manual,manual');
 result=await request('auth-expired');assert.equal(result.response.status,401);assert.equal(result.response.headers.get('x-fixture-upstream-calls'),'0');
 for(const [scenario,code,phase,upstream]of [['auth-redirect','LAPSUS_AUTH_REDIRECT','authentication','0'],['upstream-redirect','PASSERELLE_REDIRECT','passerelle','1'],['auth-network','LAPSUS_AUTH_UNAVAILABLE','authentication','0'],['upstream-network','PASSERELLE_UNAVAILABLE','passerelle','1']]){
  result=await request(scenario);assert.equal(result.response.status,502);assert.equal(result.body.code,code);assert.match(result.body.reference,/^[a-f0-9-]{36}$/);assert.equal(result.response.headers.get('x-fixture-upstream-calls'),upstream);
  const diagnostic=JSON.parse(result.response.headers.get('x-fixture-diagnostics'))[0];assert.equal(diagnostic.reference,result.body.reference);assert.equal(diagnostic.phase,phase);assert.deepEqual(Object.keys(diagnostic).sort(),['code','event','phase','reference','status']);
  for(const secret of [token,'k'.repeat(43),'secret-diagnostic-must-not-appear','11111111-1111-4111-8111-111111111111'])assert.ok(!(JSON.stringify(result.body)+JSON.stringify(diagnostic)).includes(secret));
 }
 result=await request('ready','/api/passerelle/connect',{scopes:['courses','homework','exams','messages','news']});assert.equal(result.response.status,200);assert.match(result.body.launchURL,/\/agenda\/ent-connect\?session=/);assert.match(result.response.headers.get('set-cookie'),/HttpOnly/);assert.match(result.response.headers.get('set-cookie'),/Secure/);
 console.log(JSON.stringify({ok:true,runtime:'workerd@1.20261106.1',originalBugReproduced:true,authAndPasserelleFetch:true,expiredSession401:true,redirectsRejected:true,credentialsNeverForwarded:true,PKCEAndEncryptedCookie:true,networkFailuresDistinguished:true,safeDiagnostics:true,externalNetworkDenied:true,realENTCalls:0,realEmailsSent:0}));
}finally{
 child.kill('SIGTERM');await Promise.race([closed,new Promise(resolve=>setTimeout(resolve,2000))]);if(child.exitCode===null){child.kill('SIGKILL');await closed;}fs.rmSync(temp,{recursive:true,force:true});
}
