import test from 'node:test';
import assert from 'node:assert/strict';
import {createHandler} from '../functions/api/passerelle/[[path]].js';

const ORIGIN='https://mon-ent.pages.dev',ISSUER='https://repere.84.235.226.127.sslip.io/agenda',AUTH='https://test-project.supabase.co';
const USER='11111111-1111-4111-8111-111111111111',OTHER='22222222-2222-4222-8222-222222222222';
const ID='ment-33333333-3333-4333-8333-333333333333';
const env={PASSERELLE_MANAGED_KEY:'k'.repeat(43),LAPSUS_SUPABASE_URL:AUTH,LAPSUS_SUPABASE_PUBLISHABLE_KEY:'sb_publishable_test_public_key_123456789'};
const token='synthetic-valid-lapsus-user-session-token-123456';
function fixture(){
 let time=Date.now(),user=USER,authStatus=200,upstreamStatus=200,session;
 const calls=[],logs=[];
 const handle=createHandler({now:()=>time,logger:entry=>logs.push(entry),fetcher:async(url,options={})=>{
  calls.push({url:String(url),options});assert.equal(options.redirect,'manual');
  if(url===AUTH+'/auth/v1/user'&&authStatus===304)return new Response(null,{status:304});
  if(url===AUTH+'/auth/v1/user')return Response.json({id:user,is_anonymous:false},{status:authStatus});
  assert.ok(String(url).startsWith(ISSUER+'/api/managed-ent/'),'only fixed upstream may be called');
  assert.equal(options.headers.Authorization,'Bearer '+env.PASSERELLE_MANAGED_KEY);assert.equal(options.headers['X-Lapsus-User'],user);
  assert.equal(options.redirect,'manual');assert.ok(!JSON.stringify(options).includes(token));
  if(upstreamStatus===304)return new Response(null,{status:304});
  if(upstreamStatus!==200)return Response.json({error:'synthetic-private-upstream-detail'},{status:upstreamStatus});
  if(String(url).endsWith('/sessions')){session=JSON.parse(options.body);return Response.json({launchURL:ISSUER+'/ent-connect?session='+'s'.repeat(43),sessionId:'must-not-be-returned',expiresAt:time+12*60000,connectionId:ID});}
  if(String(url).includes('/files/'))return new Response('%PDF-synthetic',{headers:{'Content-Disposition':'attachment; filename=Test.pdf'}});
  if(String(url).endsWith('/exchange')){const body=JSON.parse(options.body);assert.equal(body.code,'c'.repeat(43));assert.equal(typeof body.codeVerifier,'string');assert.equal(body.codeVerifier.length,43);return Response.json({connectionId:ID,status:'ready',lastSync:time});}
  return Response.json({connectionId:ID,status:'ready',events:[],lastSync:time});
 }});
 async function request(path,{body,method,auth=true,origin=ORIGIN,cookie,environment=env,headers={}}={}){
  const response=await handle({env:environment,request:new Request(ORIGIN+'/api/passerelle'+path,{method:method||(body===undefined?'GET':'POST'),headers:{...(auth?{Authorization:'Bearer '+token}:{}),...(origin?{Origin:origin}:{}),...(body!==undefined?{'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{}),...headers},...(body!==undefined?{body:JSON.stringify(body)}:{})})});
  return {status:response.status,headers:response.headers,body:response.headers.get('content-type')?.includes('application/octet-stream')?await response.text():await response.json()};
 }
 return {request,calls,logs,get session(){return session;},set user(value){user=value;},set time(value){time=value;},get time(){return time;},set authStatus(value){authStatus=value;},set upstreamStatus(value){upstreamStatus=value;}};
}

test('Cloudflare validates the current Lapsus user and starts a PKCE transaction without revealing server keys',async()=>{
 const f=fixture(),result=await f.request('/connect',{body:{scopes:['courses','homework']}});
 assert.equal(result.status,200);assert.equal(result.body.launchURL,ISSUER+'/ent-connect?session='+'s'.repeat(43));assert.equal(result.body.sessionId,undefined);
 assert.equal(f.session.externalUserId,USER);assert.deepEqual(f.session.scopes,['courses','homework']);assert.match(f.session.state,/^[A-Za-z0-9_-]{43}$/);assert.match(f.session.codeChallenge,/^[A-Za-z0-9_-]{43}$/);
 const cookie=result.headers.get('set-cookie');assert.match(cookie,/HttpOnly/);assert.match(cookie,/Secure/);assert.match(cookie,/SameSite=Lax/);assert.match(cookie,/Path=\/api\/passerelle/);
 for(const value of [USER,f.session.state,env.PASSERELLE_MANAGED_KEY,token])assert.ok(!cookie.includes(value));
 assert.equal(result.headers.get('cache-control'),'no-store');assert.ok(!JSON.stringify(result.body).includes(env.PASSERELLE_MANAGED_KEY));
 assert.equal(f.calls[0].url,AUTH+'/auth/v1/user');assert.equal(f.calls[0].options.headers.apikey,env.LAPSUS_SUPABASE_PUBLISHABLE_KEY);
});

test('Cloudflare rejects missing or expired authentication, foreign origins and client-supplied account identities',async()=>{
 const f=fixture();assert.equal((await f.request('/connection',{auth:false})).status,401);assert.equal(f.calls.length,0);
 assert.equal((await f.request('/connect',{origin:'https://outside.invalid',body:{scopes:['courses']}})).status,403);
 assert.equal((await f.request('/connect',{origin:null,body:{scopes:['courses']}})).status,403);
 assert.equal((await f.request('/connect',{body:{scopes:['courses'],externalUserId:OTHER}})).status,400);assert.equal(f.calls.filter(call=>call.url.endsWith('/sessions')).length,0);
 f.authStatus=401;assert.equal((await f.request('/connection')).status,401);assert.equal(f.calls.filter(call=>call.url.startsWith(ISSUER)).length,0);
});

test('the encrypted callback transaction is bound to the Lapsus account, state, issuer and expiration',async()=>{
 const f=fixture(),started=await f.request('/connect',{body:{scopes:['courses']}}),cookie=started.headers.get('set-cookie').split(';')[0];
 const body={code:'c'.repeat(43),state:f.session.state,iss:ISSUER};
 const good=await f.request('/exchange',{body,cookie});assert.equal(good.status,200);assert.equal(good.body.connectionId,ID);assert.match(good.headers.get('set-cookie'),/Max-Age=0/);
 for(const patch of [{state:'x'.repeat(43)},{iss:'https://outside.invalid'},{code:'invalid'}])assert.equal((await f.request('/exchange',{body:{...body,...patch},cookie})).status,409);
 f.user=OTHER;assert.equal((await f.request('/exchange',{body,cookie})).status,409);f.user=USER;
 f.time+=13*60000;assert.equal((await f.request('/exchange',{body,cookie})).status,409);
 assert.equal((await f.request('/exchange',{body,cookie:'lapsus_ent_transaction=corrupted'})).status,410);
});

test('Cloudflare proxies only the allowed REST paths with the server-verified subject and redacts upstream failures',async()=>{
 const f=fixture();assert.equal((await f.request('/connection',{headers:{'X-Lapsus-User':OTHER}})).status,200);
 assert.equal((await f.request('/connections/'+ID+'/agenda?from=2026-11-01&to=2026-11-15')).status,200);
 assert.equal((await f.request('/connections/'+ID+'/sync',{body:{}})).status,200);
 assert.equal((await f.request('/connections/'+ID,{method:'DELETE'})).status,200);
 assert.equal((await f.request('/connection',{method:'DELETE',headers:{'X-Lapsus-User':OTHER}})).status,200);
 const cleanup=f.calls.at(-1);assert.ok(cleanup.url.endsWith('/api/managed-ent/connection'));assert.equal(cleanup.options.method,'DELETE');assert.equal(cleanup.options.headers['X-Lapsus-User'],USER);
 assert.equal((await f.request('/connection',{method:'DELETE',auth:false})).status,401);
 assert.equal((await f.request('/connection?user='+OTHER,{method:'DELETE'})).status,404);
 for(const path of ['/admin','/connections/'+ID+'/agenda?url=https://outside.invalid','/connections/not-an-id/status','/connections/'+ID+'/status?externalUserId='+OTHER])assert.ok((await f.request(path)).status>=400);
 f.upstreamStatus=503;const unavailable=await f.request('/connection');assert.equal(unavailable.status,503);assert.ok(!JSON.stringify(unavailable.body).includes('synthetic-private-upstream-detail'));
 const unconfigured=await f.request('/connection',{environment:{...env,PASSERELLE_MANAGED_KEY:''}});assert.equal(unconfigured.status,503);assert.equal(unconfigured.body.code,'ENT_CONNECTOR_UNCONFIGURED');
 assert.equal(unavailable.body.code,undefined,'an upstream outage must never be confused with a connector that was never configured');
 assert.equal((await f.request('/connection',{environment:{...env,LAPSUS_SUPABASE_PUBLISHABLE_KEY:'sb_secret_must_never_be_used'}})).status,503);
});


test('Cloudflare supports explicit mail and news permissions and only the fixed scoped read routes',async()=>{
 const f=fixture();const started=await f.request('/connect',{body:{scopes:['courses','homework','exams','messages','news']}});assert.equal(started.status,200);assert.deepEqual(f.session.scopes,['courses','homework','exams','messages','news']);
 for(const path of ['/school/messages?offset=20&folder=inbox','/school/news?refresh=1','/detail/'+'a'.repeat(64)])assert.equal((await f.request('/connections/'+ID+path)).status,200,path);
 const download=await f.request('/connections/'+ID+'/files/'+'b'.repeat(64));assert.equal(download.status,200);assert.equal(download.body,'%PDF-synthetic');assert.equal(download.headers.get('cache-control'),'no-store');
 for(const path of ['/school/grades','/school/messages?offset=0&offset=20','/school/news?folder=inbox','/detail/not-a-reference','/files/'+'b'.repeat(64)+'?url=https://outside.invalid'])assert.ok((await f.request('/connections/'+ID+path)).status>=400,path);
 assert.equal((await f.request('/connections/'+ID+'/school/messages',{auth:false})).status,401);
});

test('every Auth or Passerelle redirect is refused before credentials can follow its destination',async()=>{
 for(const status of [300,301,302,303,304,307,308]){
  const auth=fixture();auth.authStatus=status;
  const a=await auth.request('/connection');assert.equal(a.status,502);assert.equal(a.body.code,'LAPSUS_AUTH_REDIRECT');assert.equal(auth.calls.length,1);
  const upstream=fixture();upstream.upstreamStatus=status;
  const b=await upstream.request('/connection');assert.equal(b.status,502);assert.equal(b.body.code,'PASSERELLE_REDIRECT');assert.equal(upstream.calls.length,2);
  for(const [f,result,phase]of [[auth,a,'authentication'],[upstream,b,'passerelle']]){
   assert.match(result.body.reference,/^[a-f0-9-]{36}$/);assert.equal(f.logs.length,1);assert.equal(f.logs[0].reference,result.body.reference);assert.equal(f.logs[0].phase,phase);
   assert.deepEqual(Object.keys(f.logs[0]).sort(),['code','event','phase','reference','status']);
   for(const secret of [USER,OTHER,token,env.PASSERELLE_MANAGED_KEY,'synthetic-private-upstream-detail'])assert.ok(!JSON.stringify(f.logs).includes(secret));
  }
 }
});

test('transport failures have a bounded diagnostic without raw exceptions, URLs or credentials',async()=>{
 for(const target of ['auth','passerelle']){
  const logs=[],calls=[];
  const handle=createHandler({logger:row=>logs.push(row),fetcher:async(url,options)=>{
   calls.push({url,options});assert.equal(options.redirect,'manual');
   if(target==='auth'||!String(url).startsWith(AUTH))throw new TypeError('private-exception '+token+' https://private.invalid/?token='+env.PASSERELLE_MANAGED_KEY);
   return Response.json({id:USER});
  }});
  const response=await handle({env,request:new Request(ORIGIN+'/api/passerelle/connection',{headers:{Origin:ORIGIN,Authorization:'Bearer '+token}})}),body=await response.json();
  assert.equal(response.status,502);assert.equal(body.code,target==='auth'?'LAPSUS_AUTH_UNAVAILABLE':'PASSERELLE_UNAVAILABLE');assert.equal(calls.length,target==='auth'?1:2);assert.equal(logs.length,1);assert.equal(logs[0].reference,body.reference);
  for(const privateValue of [token,env.PASSERELLE_MANAGED_KEY,'private.invalid','private-exception',USER])assert.ok(!(JSON.stringify(body)+JSON.stringify(logs)).includes(privateValue));
 }
});

test('a failing diagnostics sink cannot hide the original connection failure',async()=>{
 const handle=createHandler({logger(){throw new Error('Fixture logger failure');},fetcher:async()=>{throw new Error('Fixture network failure');}});
 const response=await handle({env,request:new Request(ORIGIN+'/api/passerelle/connection',{headers:{Origin:ORIGIN,Authorization:'Bearer '+token}})}),body=await response.json();
 assert.equal(response.status,502);assert.equal(body.code,'LAPSUS_AUTH_UNAVAILABLE');assert.match(body.reference,/^[a-f0-9-]{36}$/);
});
