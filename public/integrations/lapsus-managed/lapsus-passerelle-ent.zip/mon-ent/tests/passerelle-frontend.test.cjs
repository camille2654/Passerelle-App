const test=require('node:test');
const assert=require('node:assert/strict');
const api=require('../passerelle-ent.js');

const id='ment-11111111-1111-4111-8111-111111111111';
const info={connectionId:id,status:'ready',scopes:['courses','homework','exams'],sourceVersion:'source-version-a',lastSync:1,lastAttempt:1,stale:false};
const row=(id,date,title='Mathématiques')=>({id,title,start:date+'T09:00:00Z',end:date+'T10:00:00Z',subject:'Mathématiques',location:'Salle A',sequence:0});
const window={from:'2026-11-01',to:'2026-11-30'};
const response=(value,status=200)=>({ok:status>=200&&status<300,status,json:async()=>value});

test('callback is consumed before unrelated authentication and its code is removed even when invalid',()=>{
 for(const issuer of ['https://repere.84.235.226.127.sslip.io/agenda','https://outside.invalid']){
  let replaced=null;
  const result=api.captureCallback({pathname:'/passerelle/ent/callback',search:'?'+new URLSearchParams({code:'c'.repeat(43),state:'s'.repeat(43),iss:issuer})},{replaceState(_data,_unused,value){replaced=value;}});
  assert.equal(replaced,'/');
  if(issuer.includes('outside'))assert.ok(result.error);else{assert.equal(result.code,'c'.repeat(43));assert.equal(result.state,'s'.repeat(43));}
 }
 let changed=false;assert.equal(api.captureCallback({pathname:'/',search:'?code=supabase-code'},{replaceState(){changed=true;}}),null);assert.equal(changed,false);
});

test('partial course replacement preserves outside dates, removes cancellation and does not classify course titles as homework',()=>{
 const past=api.replaceCourses([],[row('past','2026-09-01')],{from:'2026-09-01',to:'2026-09-02'});
 const near=api.replaceCourses(past,[row('same','2026-11-05','Exercices et contrôle de connaissances'),row('removed','2026-11-06')],window);
 const far=api.replaceCourses(near,[row('far','2027-02-05')],{from:'2027-02-01',to:'2027-02-28'});
 const moved=api.replaceCourses(far,[row('same','2026-11-08')],window);
 assert.deepEqual(moved.map(event=>event.uid),['passerelle-course:past','passerelle-course:same','passerelle-course:far']);
 assert.equal(moved[1].kind,'course');assert.equal(moved[1].date,'2026-11-08');assert.equal(moved[1].status,'CONFIRMED');
 const cancelled=api.replaceCourses(moved,[],window);assert.deepEqual(cancelled.map(event=>event.uid),['passerelle-course:past','passerelle-course:far']);
 assert.ok(!cancelled.some(event=>event.status==='CANCELLED'));
});

test('work identities survive date changes and malformed snapshots never mutate the last valid arrays',()=>{
 const first=api.replaceWork([],[{id:'homework',title:'Exercice',due:'2026-11-05',kind:'homework',details:'Consigne',subject:'Mathématiques'}],window);
 const moved=api.replaceWork(first,[{id:'homework',title:'Exercice',due:'2026-11-09',kind:'homework'}],window);
 assert.equal(first[0].id,moved[0].id);assert.equal(moved[0].type,'hw');assert.equal(moved[0].due,'2026-11-09');
 const before=JSON.stringify(first);assert.throws(()=>api.replaceWork(first,[{id:'bad',due:'2026-02-31',kind:'exam'}],window));assert.equal(JSON.stringify(first),before);
 assert.throws(()=>api.replaceCourses([], [row('outside','2027-01-01')],window));
 assert.throws(()=>api.replaceCourses([], [row('bad','invalid')],window));
 const exam=api.replaceWork([],[{id:'exam',title:'Évaluation',due:'2026-11-05',kind:'exam'}],window);assert.equal(exam[0].type,'eval');
});

test('REST helper sends only the Lapsus session to same-origin functions and validates connection ownership metadata',async()=>{
 const calls=[];const client=api.createClient({getAccessToken:async()=>'synthetic-lapsus-token',fetcher:async(url,options)=>{calls.push({url,options});return response({...info,events:[]});}});
 const result=await client.agenda(id,window);assert.equal(result.connectionId,id);assert.deepEqual(result.events,[]);assert.equal(calls[0].url,'/api/passerelle/connections/'+id+'/agenda?from=2026-11-01&to=2026-11-30');assert.equal(calls[0].options.headers.Authorization,'Bearer synthetic-lapsus-token');assert.equal(calls[0].options.credentials,'same-origin');assert.equal(calls[0].options.cache,'no-store');
 assert.throws(()=>api.metadata({...info,scopes:['admin']}));assert.throws(()=>api.metadata({...info,connectionId:'other'}));
 assert.deepEqual(api.metadata({connectionId:null}),{connectionId:null});assert.equal(result.sourceVersion,'source-version-a');
 await assert.rejects(api.createClient({getAccessToken:async()=>null}).current(),/Reconnecte-toi/);
});

test('connection navigation allows only the expected Passerelle launch and no secret is persisted by the helper',async()=>{
 for(const launchURL of ['https://outside.invalid/ent-connect?session='+'a'.repeat(43),'https://repere.84.235.226.127.sslip.io/agenda/ent-connect?session='+'a'.repeat(43)+'&next=other','https://repere.84.235.226.127.sslip.io/agenda/ent-connect?session='+'a'.repeat(43)+'#fragment']){
  const client=api.createClient({getAccessToken:async()=>'synthetic',fetcher:async()=>response({launchURL})});await assert.rejects(client.connect(),/invalide/);
 }
 const launch='https://repere.84.235.226.127.sslip.io/agenda/ent-connect?session='+'a'.repeat(43);
 const client=api.createClient({getAccessToken:async()=>'synthetic',fetcher:async()=>response({launchURL:launch})});assert.equal(await client.connect(),launch);
 const unavailable=api.createClient({getAccessToken:async()=>'synthetic',fetcher:async()=>response({error:'Connexion non activée'},503)});await assert.rejects(unavailable.current(),error=>error.status===503&&error.message==='Connexion non activée');
});

test('account cleanup works without a cached connection and refuses to ignore outages or a known connected profile',async()=>{
 const calls=[];
 const client=api.createClient({getAccessToken:async()=>'synthetic-lapsus-token',fetcher:async(url,options)=>{calls.push({url,options});return response({ok:true});}});
 await client.disconnectCurrent();assert.equal(calls[0].url,'/api/passerelle/connection');assert.equal(calls[0].options.method,'DELETE');
 for(const [status,code,knownConnection,canSkip]of [[503,'ENT_CONNECTOR_UNCONFIGURED',false,true],[503,'ENT_CONNECTOR_UNCONFIGURED',true,false],[503,undefined,false,false],[401,undefined,false,false],[502,undefined,false,false]]){
  const unavailable=api.createClient({getAccessToken:async()=>'synthetic',fetcher:async()=>response({error:'Nettoyage impossible',code},status)});
  if(canSkip)await unavailable.disconnectCurrent({knownConnection});
  else await assert.rejects(unavailable.disconnectCurrent({knownConnection}),error=>error.status===status);
 }
});


test('mail and news reads validate scoped content and never put the server key or an external identity in the browser request',async()=>{
 const calls=[],extended={...info,scopes:['courses','messages','news']},ref='a'.repeat(64);
 const client=api.createClient({getAccessToken:async()=> 'synthetic-session',fetcher:async(url,options)=>{calls.push({url,options});return response({...extended,section:'messages',available:true,items:[{ref,title:'Mail du lycée'}]});}});
 assert.equal((await client.school(id,'messages')).items[0].title,'Mail du lycée');assert.ok(calls[0].url.endsWith('/school/messages'));assert.equal(calls[0].options.headers.Authorization,'Bearer synthetic-session');assert.equal(calls[0].options.headers['X-Lapsus-User'],undefined);
 await assert.rejects(()=>client.school(id,'grades'));await assert.rejects(()=>client.detail(id,'not-a-reference'));await assert.rejects(()=>client.file(id,'https://outside.invalid/file'));
 assert.deepEqual(api.metadata(extended).scopes,extended.scopes);
});
