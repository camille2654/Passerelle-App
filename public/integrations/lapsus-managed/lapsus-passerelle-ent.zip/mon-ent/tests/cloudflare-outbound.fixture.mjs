// Synthetic Auth and Passerelle. The runtime configuration denies Internet access.
const AUTH='fixture-auth.supabase.co',ISSUER='repere.84.235.226.127.sslip.io';
export default {async fetch(request){
  const url=new URL(request.url),scenario=request.headers.get('x-fixture-scenario');
  if(url.hostname===AUTH&&url.pathname==='/auth/v1/user'){
    if(request.headers.get('apikey')!=='sb_publishable_fixture_public_key_12345')return new Response('Bad fixture key',{status:400});
    if(scenario==='auth-redirect')return Response.redirect('https://must-not-receive-credentials.invalid/auth',302);
    if(scenario==='auth-expired')return Response.json({error:'Expired test session'},{status:401});
    return Response.json({id:'11111111-1111-4111-8111-111111111111',is_anonymous:false});
  }
  if(url.hostname===ISSUER&&url.pathname.startsWith('/agenda/api/managed-ent/')){
    if(request.headers.get('authorization')!=='Bearer '+'k'.repeat(43)||request.headers.get('x-lapsus-user')!=='11111111-1111-4111-8111-111111111111')return new Response('Bad fixture identity',{status:400});
    if(scenario==='upstream-redirect')return Response.redirect('https://must-not-receive-credentials.invalid/calendar',307);
    if(url.pathname.endsWith('/sessions')){
      const input=await request.json();
      if(input.externalUserId!=='11111111-1111-4111-8111-111111111111'||!/^[A-Za-z0-9_-]{43}$/.test(input.codeChallenge)||!/^[A-Za-z0-9_-]{43}$/.test(input.state))return new Response('Bad fixture transaction',{status:400});
      return Response.json({launchURL:'https://'+ISSUER+'/agenda/ent-connect?session='+'s'.repeat(43),expiresAt:Date.now()+720000});
    }
    return Response.json({connectionId:null});
  }
  return new Response('Unexpected fixture destination',{status:418});
}};
