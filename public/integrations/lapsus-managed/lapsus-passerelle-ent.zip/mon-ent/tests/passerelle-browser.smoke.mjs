import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE||'playwright');
const folder=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const server=http.createServer((req,res)=>{
  let name=new URL(req.url,'http://localhost').pathname;
  if(name==='/'||name==='/passerelle/ent/callback')name='/index.html';
  const file=path.resolve(folder,'.'+name);
  if(!file.startsWith(folder+path.sep)||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404).end();return;}
  const mime={'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png','.webmanifest':'application/manifest+json'};
  res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});fs.createReadStream(file).pipe(res);
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const root='http://127.0.0.1:'+server.address().port;
const now=Date.now(),today=new Date(),day=value=>new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Paris',year:'numeric',month:'2-digit',day:'2-digit'}).format(value);
const add=count=>new Date(today.getTime()+count*86400000),tomorrow=day(add(1));
const connectionId='ment-11111111-1111-4111-8111-111111111111';
let mailMode='ready',active=false,revision='source-a',phase=1,gate=null,gateEntered=false,releaseGate,deleted=0,exchanged=0,requests=[],cleanupStatus=200,rpcCalls=0,cleanupOrder=[];
const meta=()=>({connectionId,status:'ready',scopes:['courses','homework','exams','messages','news'],schoolName:'Lycée synthétique',student:{name:'Élève synthétique',className:'Classe de test'},lastSync:now,lastAttempt:now,stale:false,nextSyncAt:now+120000,sourceVersion:revision});
const tokenFor=user=>'Bearer synthetic-lapsus-'+user;
let browser;
const errors=[],external=[];
try{
 browser=await chromium.launch({headless:true,args:['--renderer-process-limit=1']});
 const context=await browser.newContext({viewport:{width:390,height:844},locale:'fr-FR',timezoneId:'Europe/Paris',serviceWorkers:'block'});
 await context.addInitScript(()=>{
   window.__BOOT_MS=3000;window.__fixtureUser={id:'test-a',email:'test-a@example.invalid',created_at:'2026-01-01T00:00:00Z'};
   localStorage.setItem('u:test-a:icsText',JSON.stringify('BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\nUID:manual-import\nDTSTART:20261105T120000Z\nDTEND:20261105T130000Z\nSUMMARY:Cours importé manuellement\nEND:VEVENT\nEND:VCALENDAR'));
 });
 await context.route('https://fonts.googleapis.com/**',route=>route.fulfill({contentType:'text/css',body:''}));
 await context.route('https://fonts.gstatic.com/**',route=>route.abort());
 await context.route('https://cdn.jsdelivr.net/npm/@supabase/**',route=>route.fulfill({contentType:'application/javascript',body:`window.supabase={createClient(){window.__supabaseSawQuery=location.search;const chain=()=>{const row={select(){return this},order(){return this},limit(){return this},eq(){return this},upsert(){return this},delete(){return this},maybeSingle(){return Promise.resolve({data:null,error:null})},then(resolve){const data=window.__fixtureUser.id==='test-a'?[{id:'manual-homework',title:'Mon devoir personnel',subject:'Français',due:'${tomorrow}',notes:'Note personnelle',done:false}]:[];return Promise.resolve({data,error:null}).then(resolve)}};return row};return {from(name){if(name==='homework')return chain();const row=chain();row.then=resolve=>Promise.resolve({data:[],error:null}).then(resolve);return row},async rpc(name){if(name!=='delete_my_account')throw new Error('Unexpected RPC');await window.__recordFixtureRPC();return {error:window.__fixtureRPCError||null}},auth:{async getSession(){return {data:{session:window.__fixtureUser?{user:window.__fixtureUser,access_token:'synthetic-lapsus-'+window.__fixtureUser.id}:null}}},onAuthStateChange(fn){window.__fixtureAuthEvent=fn;return {data:{subscription:{unsubscribe(){}}}}},async signOut(){window.__fixtureUser=null;window.__fixtureAuthEvent?.('SIGNED_OUT');return {error:null}}}}}};` }));
 await context.route('https://repere.84.235.226.127.sslip.io/agenda/ent-connect?**',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:'<!doctype html><h1>Connexion ENT de test</h1>'}));
 await context.route(root+'/api/passerelle/**',async route=>{
  const request=route.request(),url=new URL(request.url()),suffix=url.pathname.slice('/api/passerelle'.length),authorization=request.headers().authorization;
  requests.push({path:suffix,method:request.method(),authorization});
  assert.ok(authorization===tokenFor('test-a')||authorization===tokenFor('test-b'));
  const json=(value,status=200)=>route.fulfill({status,contentType:'application/json',body:JSON.stringify(value)});
  if(suffix==='/connect')return json({launchURL:'https://repere.84.235.226.127.sslip.io/agenda/ent-connect?session='+'x'.repeat(43)});
  if(suffix==='/exchange'){exchanged++;assert.deepEqual(request.postDataJSON(),{code:'c'.repeat(43),state:'s'.repeat(43),iss:'https://repere.84.235.226.127.sslip.io/agenda'});active=true;return json(meta());}
  if(suffix==='/connection'&&request.method()==='DELETE'){
    if(cleanupStatus!==200)return json({error:'Nettoyage ENT temporairement indisponible'},cleanupStatus);
    cleanupOrder.push('cleanup');if(authorization===tokenFor('test-a')){active=false;deleted++;}return json({ok:true});
  }
  if(suffix==='/connection')return json(active&&authorization===tokenFor('test-a')?meta():{connectionId:null});
  if(suffix==='/connections/'+connectionId&&request.method()==='DELETE'){active=false;deleted++;return json({ok:true});}
  if(/\/(?:activity|sync)$/.test(suffix))return json(meta());
  if(suffix.endsWith('/school/messages')&&mailMode==='failure')return json({error:'Panne temporaire de la messagerie'},503);
  if(suffix.endsWith('/school/messages')&&mailMode==='unavailable')return json({...meta(),available:false,items:[],hasMore:false,warning:'La messagerie n’est pas fournie par cet ENT.'});
  if(suffix.endsWith('/school/messages'))return json({...meta(),available:true,items:[{ref:(url.searchParams.get('offset')?'d':'a').repeat(64),title:url.searchParams.get('offset')?'Mail précédent':'Réunion des élèves',sender:'Vie scolaire',date:tomorrow+'T10:00:00Z',preview:'Une information pour demain',read:false}],hasMore:!url.searchParams.get('offset'),offset:Number(url.searchParams.get('offset')||0)});
  if(suffix.endsWith('/school/news'))return json({...meta(),available:true,items:[{ref:'b'.repeat(64),title:'Actualité du lycée',date:tomorrow+'T10:00:00Z',preview:'Présentation de la sortie'}],hasMore:false});
  if(suffix.endsWith('/detail/'+'a'.repeat(64))||suffix.endsWith('/detail/'+'d'.repeat(64)))return json({...meta(),kind:'message',title:'Réunion des élèves',items:[{author:'Vie scolaire',date:tomorrow+'T10:00:00Z',text:'Contenu intégral du mail <script>alert(1)</script>',files:[{ref:'c'.repeat(64),name:'Document.pdf'}]}]});
  if(suffix.endsWith('/detail/'+'b'.repeat(64)))return json({...meta(),kind:'news',title:'Actualité du lycée',author:'Le lycée',text:'Tous les détails de la sortie',files:[]});
  if(suffix.endsWith('/files/'+'c'.repeat(64)))return route.fulfill({status:200,contentType:'application/octet-stream',body:Buffer.from('%PDF-test')});
  if(suffix.endsWith('/agenda')){
    if(gate){gateEntered=true;await gate;}
    const date=tomorrow,rows=revision==='source-b'?[{id:'new-profile',title:'Nouveau profil',start:date+'T08:00:00Z',end:date+'T09:00:00Z',location:'Salle B',subject:'Mathématiques'}]:[{id:'stable',title:'Exercices et contrôle de connaissances',start:date+(phase===1?'T09:00:00Z':'T10:00:00Z'),end:date+(phase===1?'T10:00:00Z':'T11:00:00Z'),location:'Salle A',subject:'Mathématiques'},...(phase===1?[{id:'removed',title:'Cours supprimé ensuite',start:date+'T11:00:00Z',end:date+'T12:00:00Z',subject:'Français'}]:[])];
    return json({...meta(),events:rows.filter(row=>row.start.slice(0,10)>=url.searchParams.get('from')&&row.start.slice(0,10)<=url.searchParams.get('to'))});
  }
  if(suffix.endsWith('/homework'))return json({...meta(),available:true,items:[{id:'work-stable',title:'Devoir ENT',details:'Consigne reçue',due:phase===1?tomorrow:day(add(2)),subject:'Mathématiques',kind:'homework',done:false},{id:'exam-stable',title:'Contrôle ENT',details:'Réviser',due:tomorrow,subject:'Français',kind:'exam',done:false}]});
  return json({error:'Endpoint de test absent'},404);
 });
 const page=await context.newPage();await page.exposeFunction('__recordFixtureRPC',()=>{rpcCalls++;cleanupOrder.push('rpc');});page.setDefaultTimeout(30000);page.setDefaultNavigationTimeout(45000);
 page.on('pageerror',error=>errors.push(error.message));
 page.on('request',request=>{const url=new URL(request.url());if(['http:','https:'].includes(url.protocol)&&![root,'https://cdn.jsdelivr.net','https://fonts.googleapis.com','https://fonts.gstatic.com','https://repere.84.235.226.127.sslip.io'].includes(url.origin))external.push(url.origin);});
 await page.goto(root+'/',{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>events.some(event=>event.uid==='manual-import'));
 await page.getByRole('button',{name:'Réglages',exact:true}).click();
 await page.locator('[data-act="view"][data-v="connexion-ent"]').click();
 await page.locator('.ent-connection').getByRole('heading',{name:'Connecter mon ENT',exact:true}).waitFor();
 assert.equal(await page.locator('.ent-powered').innerText(),'Powered by PSRL');
 assert.equal((await page.locator('.ent-connection').innerText()).includes('Passerelle'),false);
 assert.equal(await page.locator('.ent-connection input[type=password]').count(),0);
 await page.locator('.ent-connection').getByRole('button',{name:'Connecter mon ENT',exact:true}).click();
 await page.getByRole('heading',{name:'Connexion ENT de test',exact:true}).waitFor();
 const callback=root+'/passerelle/ent/callback?'+new URLSearchParams({code:'c'.repeat(43),state:'s'.repeat(43),iss:'https://repere.84.235.226.127.sslip.io/agenda'});
 await page.goto(callback,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>managedConnection?.connectionId&&managedCourses.length===2&&!managedBusy);
 assert.equal(await page.evaluate(()=>window.__supabaseSawQuery),'');assert.equal(new URL(page.url()).pathname,'/');assert.equal(new URL(page.url()).search,'');assert.equal(exchanged,1);console.log(JSON.stringify({stage:'callback-and-rest-loaded'}));
 assert.equal(await page.evaluate(()=>events.find(event=>event.uid==='passerelle-course:stable').kind),'course');
 assert.deepEqual(await page.evaluate(()=>hwItems().map(item=>item.title).sort()),['Devoir ENT','Mon devoir personnel']);
 assert.equal(await page.evaluate(()=>evalItems()[0].title),'Contrôle ENT');
 await page.locator('#nav [data-v=lycee]').click();await page.getByText('Réunion des élèves',{exact:true}).waitFor();await page.getByText('Actualité du lycée',{exact:true}).waitFor();
 await page.locator('.ent-mail').first().click();await page.locator('#modal .ent-body').getByText('Contenu intégral du mail <script>alert(1)</script>',{exact:true}).waitFor();assert.equal(await page.locator('#modal script').count(),0);
 const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:'Document.pdf',exact:true}).click();assert.equal((await downloadPromise).suggestedFilename(),'Document.pdf');
 await page.locator('#modal').getByRole('button',{name:'Fermer',exact:true}).click();await page.getByRole('button',{name:'Afficher tous les mails',exact:true}).click();await page.getByRole('button',{name:'Afficher les mails précédents',exact:true}).click();await page.getByText('Mail précédent',{exact:true}).waitFor();
 await page.getByRole('button',{name:'‹ Retour à Mon lycée',exact:true}).click();await page.getByRole('button',{name:'Lire l’actualité',exact:false}).click();await page.getByText('Tous les détails de la sortie',{exact:true}).waitFor();await page.locator('#modal').getByRole('button',{name:'Fermer',exact:true}).click();
 mailMode='failure';await page.evaluate(()=>refreshManaged({manual:true}));assert.ok(await page.evaluate(()=>managedSchool.messages.items.length>0),'a temporary error keeps the previous mails');await page.getByText('Panne temporaire de la messagerie',{exact:true}).waitFor();
 mailMode='unavailable';await page.evaluate(()=>refreshManaged({manual:true}));assert.equal(await page.evaluate(()=>managedSchool.messages.items.length),0);assert.equal(await page.getByRole('button',{name:'Afficher tous les mails',exact:true}).isDisabled(),true);
 mailMode='ready';await page.evaluate(()=>refreshManaged({manual:true}));
 await page.getByRole('button',{name:'Réglages',exact:true}).click();await page.locator('[data-act="view"][data-v="connexion-ent"]').click();
 await page.locator('.ent-connection').getByRole('heading',{name:'Mon ENT connecté',exact:true}).waitFor();
 await page.locator('.ent-manual>summary').click();assert.equal(await page.locator('#icsUrl').isVisible(),true);
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
 fs.mkdirSync(path.join(folder,'test-results'),{recursive:true});await page.screenshot({path:path.join(folder,'test-results/lapsus-ent-mobile.png'),animations:'disabled'});
 await page.evaluate(()=>{autoDone['passerelle-work:work-stable']=true;ctrlDone['passerelle-work:exam-stable']=true;});
 phase=2;await page.evaluate(()=>refreshManaged({manual:true}));
 assert.equal(await page.evaluate(()=>events.filter(event=>event.uid==='passerelle-course:stable').length),1);assert.equal(await page.evaluate(()=>events.filter(event=>event.status==='CANCELLED').length),0);
 assert.equal(await page.evaluate(()=>events.some(event=>event.uid==='passerelle-course:removed')),false);
 assert.equal(await page.evaluate(()=>hwItems().find(item=>item.id==='passerelle-work:work-stable').done),true);assert.equal(await page.evaluate(()=>evalItems()[0].done),true);
 console.log(JSON.stringify({stage:'snapshots-updated'}));revision='source-b';await page.evaluate(()=>refreshManaged());assert.deepEqual(await page.evaluate(()=>managedCourses.map(event=>event.uid)),['passerelle-course:new-profile']);
 await page.locator('.ent-connection').getByRole('button',{name:'Déconnecter',exact:true}).click();await page.locator('#modal').getByRole('button',{name:'Déconnecter',exact:true}).click();
 await page.waitForFunction(()=>!managedConnection);assert.equal(deleted,1);console.log(JSON.stringify({stage:'disconnected-and-manual-restored'}));assert.ok(await page.evaluate(()=>events.some(event=>event.uid==='manual-import')));assert.ok(await page.evaluate(()=>hwItems().some(item=>item.id==='manual-homework')));
 // New login or remote sign-out cannot apply another account's delayed REST response.
 active=true;await page.evaluate(()=>refreshManaged());
 gate=new Promise(resolve=>{releaseGate=resolve;});
 await page.evaluate(()=>void refreshManaged());
 for(let attempt=0;!gateEntered&&attempt<100;attempt++)await page.waitForTimeout(100);
 assert.equal(gateEntered,true,'a delayed agenda read is in flight before logout');
 await page.evaluate(()=>leaveApp());releaseGate();gate=null;
 await page.locator('#authSubmit').waitFor();await page.waitForTimeout(200);
 assert.equal(await page.evaluate(()=>managedConnection),null);assert.equal(await page.evaluate(()=>managedCourses.length),0);assert.equal(await page.locator('#main').innerText(),'');
 await page.evaluate(async()=>{window.__fixtureUser={id:'test-b',email:'test-b@example.invalid'};user=window.__fixtureUser;await enterApp();});
 assert.equal(await page.evaluate(()=>managedConnection),null);assert.equal(await page.evaluate(()=>events.length),0);assert.equal(await page.evaluate(()=>hwItems().length),0);
 assert.ok(await page.evaluate(()=>localStorage.getItem('u:test-a:icsText')));
 for(const width of [320,1440]){await page.setViewportSize({width,height:900});await page.getByRole('button',{name:'Réglages',exact:true}).click();await page.locator('[data-act="view"][data-v="connexion-ent"]').click();await page.evaluate(()=>document.documentElement.dataset.theme='dark');assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);}
 // Account removal must clean up remotely even on a device without a cached connection.
 await page.evaluate(async()=>{user=window.__fixtureUser={id:'test-a',email:'test-a@example.invalid'};await enterApp();await refreshManaged();setManagedConnection({connectionId:null},true);});
 cleanupStatus=503;await page.evaluate(()=>deleteAccountModal());
 assert.equal(rpcCalls,0);assert.equal(await page.evaluate(()=>user?.id),'test-a');
 await page.locator('#modal .mt').filter({hasText:/^Suppression impossible$/}).waitFor();
 cleanupStatus=200;await page.evaluate(async()=>{window.__fixtureRPCError={message:'Suppression Supabase refusée dans le test'};await deleteAccountModal();});
 assert.equal(active,false);assert.equal(rpcCalls,1);assert.equal(await page.evaluate(()=>user?.id),'test-a');
 await page.locator('#modal .mt').filter({hasText:/^Suppression impossible$/}).waitFor();
 await page.evaluate(async()=>{window.__fixtureRPCError=null;await deleteAccountModal();});
 assert.equal(rpcCalls,2);assert.equal(await page.evaluate(()=>user),null);assert.deepEqual(cleanupOrder,['cleanup','rpc','cleanup','rpc']);
 assert.equal(await page.evaluate(()=>localStorage.getItem('u:test-a:managedENT')),null);
 assert.equal(await page.evaluate(()=>localStorage.getItem('u:test-a:icsText')),null);
 await page.locator('#modal .mt').filter({hasText:/^Compte supprimé$/}).waitFor();
 assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
 console.log(JSON.stringify({ok:true,callbackBeforeSupabase:true,noExtraPasserelleAccount:true,restCoursesHomeworkExams:true,mailAndNews:true,fullContents:true,privateAttachment:true,mailPagination:true,missingSourceDisabled:true,temporaryFailureKeepsCopy:true,stableUpdates:true,removedCourses:true,manualImportsPreserved:true,localTasksPreserved:true,sourceChangeCacheReset:true,lateResponseIsolation:true,logoutAndAccountIsolation:true,accountDeletionCleanup:true,rpcFailureVisible:true,widths:[320,390,1440],dark:true,realENTCalls:0,realEmails:0}));
}finally{releaseGate?.();await browser?.close();server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}
