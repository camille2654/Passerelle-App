import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
const {chromium}=await import('playwright').catch(()=>import('/home/ubuntu/apps/agenda-bridge/node_modules/playwright/index.mjs'));
const root=path.dirname(fileURLToPath(import.meta.url));
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.ttf':'font/ttf','.wav':'audio/wav'};
const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return;}fs.readFile(file,(e,data)=>{if(e){res.writeHead(404).end();return;}res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(data);});});
server.listen(0,'127.0.0.1');await once(server,'listening');
let browser,encoder;
try{
 browser=await chromium.launch({headless:true,args:['--renderer-process-limit=1','--disable-dev-shm-usage']});
 const page=await browser.newPage({viewport:{width:540,height:960},deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(`http://127.0.0.1:${server.address().port}/studio.html?render=1`);
 await page.evaluate(()=>window.motionReady);
 const checkFrames=[1,3.3,6.8,10.2,12.8,15.3,18.7,23.8];
 for(const t of checkFrames){const data=await page.evaluate(t=>{window.renderFrame(t);return document.querySelector('canvas').toDataURL('image/png').split(',')[1];},t);fs.writeFileSync(path.join(root,'assets',`frame-${t}.png`),Buffer.from(data,'base64'));}
 const poster=await page.evaluate(()=>{window.renderFrame(23.8);return document.querySelector('canvas').toDataURL('image/png').split(',')[1];});
 fs.writeFileSync(path.join(root,'poster.png'),Buffer.from(poster,'base64'));
 if(process.argv.includes('--preview')){console.log('Preview frames captured.');process.exitCode=0;}
 else{
  const log=fs.openSync(path.join(root,'render.log'),'w');
  encoder=spawn('ffmpeg',['-hide_banner','-y','-f','image2pipe','-framerate','30','-vcodec','mjpeg','-i','pipe:0','-i',path.join(root,'assets/soundtrack.wav'),'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p','-threads','1','-c:a','aac','-b:a','160k','-ar','44100','-t','25','-movflags','+faststart','-metadata','title=Passerelle — Demain, c’est clair.','-metadata','comment=Motion original. Interface réelle, données fictives. Musique originale.',path.join(root,'passerelle-demain-cest-clair.mp4')],{stdio:['pipe','ignore',log]});
  let failure;encoder.on('error',e=>failure=e);encoder.stdin.on('error',e=>failure=e);
  const done=once(encoder,'close');
  for(let i=0;i<750;i++){
   if(failure)throw failure;
   const jpeg=await page.evaluate(t=>{window.renderFrame(t);return document.querySelector('canvas').toDataURL('image/jpeg',.96).split(',')[1];},i/30);
   if(!encoder.stdin.write(Buffer.from(jpeg,'base64')))await once(encoder.stdin,'drain');
   if(i%90===0)console.log(`Rendering ${Math.floor(i/30)} / 25 seconds`);
  }
  encoder.stdin.end();
  const [code]=await done;fs.closeSync(log);
  if(code!==0)throw new Error('FFmpeg failed '+code);
  if(errors.length)throw new Error(errors.join('; '));
  console.log('Rendered 750 frames, 1080×1920, 30fps, H264/AAC.');
 }
}finally{encoder?.stdin?.destroy();await browser?.close();await new Promise(resolve=>server.close(resolve));}
