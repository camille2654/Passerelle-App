#!/usr/bin/env python3
"""Original, gentle 25-second score for the Passerelle launch motion.

All instruments are synthesized here; no samples or downloaded music are used.
Run with Python's standard library. The output is stereo PCM, 44.1 kHz, 16 bit.
"""

from array import array
import math
from pathlib import Path
import random
import struct
import wave


RATE = 44_100
DURATION = 25.0
FRAMES = int(RATE * DURATION)
LEFT = array("f", [0.0]) * FRAMES
RIGHT = array("f", [0.0]) * FRAMES
RNG = random.Random(8173)
TAU = math.tau


def frequency(midi):
    return 440.0 * 2.0 ** ((midi - 69.0) / 12.0)


def add_sound(start, length, sample, volume=1.0, pan=0.0, echo=False):
    first = max(0, int(start * RATE))
    count = min(int(length * RATE), FRAMES - first)
    gain_left = math.sqrt((1.0 - pan) / 2.0) * volume
    gain_right = math.sqrt((1.0 + pan) / 2.0) * volume
    delay = int(0.192 * RATE)
    for i in range(count):
        value = sample(i / RATE)
        frame = first + i
        LEFT[frame] += value * gain_left
        RIGHT[frame] += value * gain_right
        if echo and frame + delay < FRAMES:
            # A single quiet, opposite-side reflection creates gentle space.
            LEFT[frame + delay] += value * gain_right * 0.105
            RIGHT[frame + delay] += value * gain_left * 0.105


def pluck(start, midi, volume=0.11, pan=0.0, length=2.1):
    hz = frequency(midi)

    def sound(t):
        attack = 1.0 - math.exp(-t * 220.0)
        tail = math.exp(-t * 3.0)
        finish = min(1.0, max(0.0, (length - t) / 0.15))
        tone = (
            math.sin(TAU * hz * t)
            + 0.21 * math.exp(-t * 3.3) * math.sin(TAU * hz * 2.0 * t)
            + 0.045 * math.exp(-t * 5.0) * math.sin(TAU * hz * 3.0 * t)
        )
        return tone * attack * tail * finish

    add_sound(start, length, sound, volume, pan, echo=True)


def pad(start, length, notes, volume=0.033):
    for j, midi in enumerate(notes):
        hz = frequency(midi)
        pan = -0.45 + j * 0.9 / max(1, len(notes) - 1)
        phase = RNG.random() * TAU

        def sound(t, hz=hz, phase=phase):
            attack = min(1.0, t / 1.25)
            release = min(1.0, max(0.0, (length - t) / 1.6))
            envelope = math.sin(attack * math.pi / 2.0) ** 2 * release**2
            drift = 0.006 * math.sin(TAU * 0.23 * t + phase)
            fundamental = math.sin(TAU * hz * t + drift)
            detune = math.sin(TAU * hz * 1.0016 * t + phase)
            return envelope * (
                0.65 * fundamental
                + 0.26 * detune
                + 0.055 * math.sin(TAU * hz * 2.0 * t)
            )

        add_sound(start, length, sound, volume, pan)


def bass(start, midi, length=1.75, volume=0.11):
    hz = frequency(midi)

    def sound(t):
        envelope = (1.0 - math.exp(-t * 30.0)) * math.exp(-t * 2.6)
        release = min(1.0, max(0.0, (length - t) / 0.22))
        return envelope * release * (
            math.sin(TAU * hz * t) + 0.12 * math.sin(TAU * hz * 2.0 * t)
        )

    add_sound(start, length, sound, volume)


def pulse(start, volume=0.043):
    def sound(t):
        envelope = (1.0 - math.exp(-t * 450.0)) * math.exp(-t * 25.0)
        phase = TAU * (63.0 * t + 19.0 * 0.024 * (1.0 - math.exp(-t / 0.024)))
        return math.sin(phase) * envelope

    add_sound(start, 0.32, sound, volume)


def chime(start, notes, volume=0.066):
    for j, midi in enumerate(notes):
        pluck(start + j * 0.092, midi, volume, -0.17 + j * 0.17, 2.4)


def compose():
    # Dmaj9 -> Bm7 -> Gmaj9 -> Asus2 -> Dmaj9; sustained voices overlap softly.
    pad(0.0, 5.8, [50, 57, 61, 64, 66], 0.030)
    pad(3.9, 5.9, [47, 54, 57, 62, 66], 0.029)
    pad(7.7, 10.0, [43, 54, 57, 59, 62], 0.029)
    pad(16.0, 6.1, [45, 52, 57, 59, 64], 0.031)
    pad(20.0, 5.0, [50, 57, 61, 64, 66], 0.031)

    # An understated offbeat figure, with plenty of breathing room.
    phrases = [
        (0.85, [66, 69, 73, 69], [0.0, 0.64, 1.61, 2.53]),
        (4.72, [66, 62, 69, 66], [0.0, 0.74, 1.69, 2.48]),
        (8.67, [66, 69, 71, 74, 71, 69], [0.0, 0.75, 1.58, 2.76, 4.14, 5.51]),
        (16.87, [64, 69, 71, 76], [0.0, 0.66, 1.58, 2.57]),
        (21.00, [73, 69, 66, 62], [0.0, 0.51, 1.22, 1.97]),
    ]
    for onset, notes, offsets in phrases:
        for j, (note, offset) in enumerate(zip(notes, offsets)):
            volume = 0.095 if j % 3 else 0.115
            pluck(onset + offset, note, volume, 0.19 if j % 2 else -0.19)

    for start, root in [(0.62, 38), (3.02, 38), (4.52, 35), (6.82, 35),
                        (8.42, 43), (10.72, 43), (13.02, 43), (15.32, 43),
                        (16.72, 45), (19.02, 45), (20.72, 38), (23.02, 38)]:
        bass(start, root)

    # Sparse soft pulses carry the middle section, then leave the final logo room.
    for i in range(16):
        pulse(2.15 + i * (60.0 / 104.0) * 2.0, 0.037 if i % 2 else 0.044)

    chime(0.60, [78, 81], 0.051)
    chime(4.40, [74, 78], 0.048)
    chime(8.20, [78, 81, 83], 0.051)
    chime(16.50, [76, 81], 0.050)
    chime(20.50, [78, 81, 85], 0.065)


def export():
    # Smooth master fades and a fixed gentle peak, with deterministic TPDF dither.
    peak_before = 0.0
    for i in range(FRAMES):
        t = i / RATE
        fade_in = min(1.0, t / 0.65)
        fade_out = min(1.0, max(0.0, (DURATION - t) / 2.0))
        envelope = math.sin(fade_in * math.pi / 2.0) ** 2 * fade_out**1.7
        LEFT[i] *= envelope
        RIGHT[i] *= envelope
        peak_before = max(peak_before, abs(LEFT[i]), abs(RIGHT[i]))

    gain = 0.50 / max(peak_before, 1e-12)
    output = Path(__file__).parent / "assets" / "soundtrack.wav"
    output.parent.mkdir(parents=True, exist_ok=True)
    peak = 0
    power = 0.0
    clipped = 0
    with wave.open(str(output), "wb") as handle:
        handle.setnchannels(2)
        handle.setsampwidth(2)
        handle.setframerate(RATE)
        for first in range(0, FRAMES, 4096):
            block = bytearray()
            for i in range(first, min(first + 4096, FRAMES)):
                for channel in (LEFT, RIGHT):
                    sample = channel[i] * gain
                    value = round(sample * 32767.0 + RNG.random() - RNG.random())
                    clipped += int(abs(value) > 32767)
                    value = min(32767, max(-32768, value))
                    peak = max(peak, abs(value))
                    power += (value / 32768.0) ** 2
                    block.extend(struct.pack("<h", value))
            handle.writeframesraw(block)

    with wave.open(str(output), "rb") as handle:
        seconds = handle.getnframes() / handle.getframerate()
        assert handle.getnchannels() == 2
        assert handle.getsampwidth() == 2
        assert seconds == DURATION
    assert clipped == 0
    assert peak < 32767
    print(f"Output: {output}")
    print(f"Duration: {seconds:.3f} s; stereo {RATE} Hz / 16-bit PCM")
    print(f"Peak: {20 * math.log10(peak / 32768.0):.2f} dBFS; clipped samples: {clipped}")
    print(f"RMS: {20 * math.log10(math.sqrt(power / (FRAMES * 2))):.2f} dBFS")
    print("Original synthesized composition, with transition cues at 0.6, 4.4, 8.2, 16.5 and 20.5 seconds.")


if __name__ == "__main__":
    compose()
    export()
