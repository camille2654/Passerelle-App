# Passerelle — Demain, c’est clair.

Film de lancement original de 25 secondes, vertical 9:16, 1080 × 1920, 30 images/seconde. MP4 H.264 + AAC, lecture compatible avec les navigateurs modernes et les téléphones.

Ouvrir `index.html` avec un serveur HTTP pour voir le MP4. `studio.html` contient l’animation originale pilotée par JavaScript : lecture, pause, son et déplacement dans le temps. Exemple : `python3 -m http.server 8034` puis ouvrir `http://localhost:8034/`.

La police et le symbole proviennent de l’identité existante de Passerelle. Les captures montrent la véritable interface, générée avec un compte temporaire et des données fictives. Aucun compte de production, secret, token ou document scolaire réel n’a été utilisé dans ces captures. Les informations disponibles dépendent de l’établissement. Ce film ne promet ni hausse des notes ni gain de temps chiffré.

Le son est une composition originale de 25 secondes, créée par synthèse dans `audio.py` : nappes, notes pincées, pulsation discrète et chimes. Aucun morceau tiers ni voix n’est utilisé. La vidéo reste compréhensible sans le son.

Pour modifier le film, éditer `motion.js`. Le temps de chaque scène est déterministe ; `window.renderFrame(secondes)` dessine une image. `render.mjs` utilise Playwright et FFmpeg pour exporter 750 images en MP4 ; installer Playwright et FFmpeg sur la machine d’export. Les sources visuelles et audio se trouvent dans `assets/`. Les fichiers de vérification et les journaux ne font pas partie de la page publique.

Scènes : question du soir (0–4,4 s), informations à réunir (4,4–8,2 s), accueil réel (8,2–11,7 s), cours et devoirs (11,7–16,5 s), rappel (16,5–20,5 s), signature et appel à découvrir l’app (20,5–25 s).

Police Manrope : licence SIL Open Font License incluse dans `assets/OFL.txt`.
